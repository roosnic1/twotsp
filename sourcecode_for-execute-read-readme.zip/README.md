#the "twotsp" Project


##Goal
Find the almost two best paths that never use the same edge through a number of points

##Members 
Jérémie Blaser, Martin Eigenmann and Nicolas Roos

##Install
You must have python and pip on your operating system to intall all the required libaries. Install them with the following command.
```python
pip install -r requirements.txt
```

##Execute
Normal Execution:
```python
python main.py
```

Execution with test cases:
```python
python exec.py
```
Sometimes this script hangs with the ME Algorithmen. Press Ctrl + C and retry.